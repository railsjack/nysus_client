Nysus.Views.AccountView = Backbone.View.extend({

    initialize: function () {
    },

    render: function () {
        this.$el.html(this.template());
        this.getData();
        return this;
    },

    getData: function(){
    	$.ajax({
            type: 'GET',
            url: 'http://107.170.224.217:3000/api/v1/users/123.json',
            dataType: 'json',
            data: {
                'token': store.get('token'),
            },
            success: function(data) {
                console.log(data);
                for(var i = 0; i < data.establishments.length; i++){
                	console.log(data.establishments[i]);
                	$("#favorites").append("<li><a class='btn btn-red btn-block' href='#establishments/"+data.establishments[i].establishment.id+"'>"+data.establishments[i].establishment.name+" <span class='glyphicon glyphicon-chevron-right pull-right'></span></a></li>");
                }
            },
            error: function(xhr, status, error) {
                console.log(error);
            }
        });
    }

});