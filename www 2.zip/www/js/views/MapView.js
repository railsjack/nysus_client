Nysus.Views.MapView = Backbone.View.extend({

    tagName:'div',

    id: 'map_view',

    initialize:function () {
        var self = this;
        this.bounds = new google.maps.LatLngBounds();
        // possibly use a new collection for the map that adapts to store.js
    },

    render:function () {
        this.$el.empty();

        if($('#map').length < 1) {
            this.appendMap();
        } else { alert('keeping map') }

        return this;
    },

    appendMap: function() {
        this.buildMap()
        this.addEstablishments();
        this.addCurrentPositionMarker();
        this.adjustMapPositioning();
        this.map.fitBounds(this.bounds);
    },

    getRealContentHeight: function() {
        var footer = $('#footer');
        var header = $("div[data-role='navigation']:visible");
        var content = $(".page");
        var viewport_height = $(window).height();

        var content_height = viewport_height - header.outerHeight() - footer.outerHeight();
        if((content.outerHeight() - header.outerHeight() - footer.outerHeight()) <= viewport_height) {
            content_height -= (content.outerHeight() - content.height());
        }
        return content_height;
    },

    addCurrentPositionMarker: function() {
        var userLatLng = new google.maps.LatLng(store.get('latitude'), store.get('longitude'));

        this.currentPositionMarker = new RichMarker({
          position: userLatLng,
          map: this.map,
          draggable: false,
          flat: true,
          content: '<i class="icon-cd current-position"></i>'
        });

        this.bounds.extend(this.currentPositionMarker.position);
        this.map.fitBounds(this.bounds);
    },

    updateCurrentPositionMarker: function() {
        var userLatLng = new google.maps.LatLng(store.get('latitude'), store.get('longitude'));
        this.currentPositionMarker.setPosition(userLatLng);
    },

    adjustMapPositioning: function(){
        var that = this;

        this.$('#map').css('height', this.getRealContentHeight());
        this.$('#map').css('position', 'relative');
        this.$('#map').css('top', '1px');

        // $('#establishments_map').css('height', this.getRealContentHeight());

        $( window ).resize(function() {
            this.$('#map').css('height', that.getRealContentHeight());
            this.$('#map').css('position', 'relative');
            this.$('#map').css('top', '1px');

            // $('#establishments_map').css('height', that.getRealContentHeight());
        });
    },

    buildMap: function() {
        this.$el.append('<div id="map"></div>');

        var styleArray = [
          {
            featureType: "poi.business",
            elementType: "labels",
            stylers: [
              { visibility: "off" }
            ]
          }
        ];

        var mapOptions = {
            center: new google.maps.LatLng(store.get('latitude'), store.get('longitude')),
            zoom: 11,
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            mapTypeControl: false,
            streetViewControl: false,
            styles: styleArray
        };
        this.map = new google.maps.Map(this.$('#map')[0], mapOptions);

        console.log('resizing');
        google.maps.event.trigger(this.map, 'resize')
    },

    addEstablishments: function() {
        var that = this;
        var establishments = store.get('establishments_list_map-coordinates')

        for (i = 0; i < establishments.length; i++) {
            marker = new RichMarker({
              position: new google.maps.LatLng(establishments[i].latitude, establishments[i].longitude),
              map: this.map,
              draggable: false,
              flat: true,
              content: '<i class="icon-glass" style="font-size: 40px; color: #952e2c; text-shadow: 1px -2px 4px #000; cursor: pointer;"></i>',
              animation: google.maps.Animation.DROP
            });

            this.bounds.extend(marker.position);

            google.maps.event.addListener(marker, 'click', (function (marker, i) {
                return function () {
                    that.openModal(establishments[i]);
                }
            })(marker, i));
        }
    },

    refreshMap: function() {
        google.maps.event.trigger(this.map, 'resize');
        this.map.fitBounds(this.bounds);
    },

    openModal: function(establishment) {
        this.closeModals();
        var view = new Nysus.Views.MapModalView({model: establishment})
        Nysus.mapModal = new Backbone.BootstrapModal({
            content: view,
            id: 'map_establishment_modal',
            modalOptions: { backdrop: false },
            showFooter: false,
            animate: true,
            allowCancel: true,
            escape: true,
        });
        Nysus.mapModal.open();
    },

    closeModals: function() {
        if( $('.modal').length > 0 ) {
            $('.modal').remove();
        }
    }
});
