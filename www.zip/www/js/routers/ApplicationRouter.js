Nysus.Routers.AppRouter = Backbone.Router.extend({

    routes: {
        "":                          "home",
        "establishments":  "establishments_list",
        "establishments/map":  "establishments_map",
        "establishments/:id":    "establishment_show",
        "search":    "search",
        "login": "login",
        "account": "account"
    },

    // before: {
    //     '*any': function(fragment, args) {
    //         debugger;
    //         try {
    //             if(typeof(Nysus.mapModal.type) != "undefined") {
    //                 console.log(Nysus.mapModal.type);
    //                 alert('closing');
    //                 Nysus.mapModal.close();
    //             }
    //         } catch(e) {
    //             console.log('no modal');
    //         }
    //     }
    // },

    after: {
            'establishments/map': function(fragment) {
                //Nysus.mapView.refreshMap();
            }
        },

    initialize: function () {
        Nysus.slider = new PageSlider($('body'));

        this.bind('all', function (trigger, args) {
               var routeData = trigger.split(":");
               $('.modal').remove();
        });

        $('.back-button').on('click', function(event){
            window.history.go(-1);
        });
    },

    home: function () {
        // Since the home view never changes, we instantiate it and render it only once
        if (!Nysus.homeView) {
            Nysus.homeView = new Nysus.Views.HomeView();
            Nysus.homeView.render();
        } else {
            console.log('reusing home view');
            Nysus.homeView.delegateEvents(); // delegate events when the view is recycled
        }
        $('#footer').fadeOut();
        Nysus.slider.slidePage(Nysus.homeView.$el);
    },


    search: function () {
        Nysus.searchView = new Nysus.Views.SearchView()
        Nysus.slider.slidePage(Nysus.searchView.render().$el);
    },

    // consider taking location argument
    establishments_list: function() {
        collection = new Nysus.Models.EstablishmentCollection();

        collection.fetch({
            success: function(data) {
                // Nysus.Utils.maps.storeEstablishmentsGeoData(data);

                var geo_data = _.map(data.models, function(establishment){
                    establishment_coordinates = {};
                    establishment_coordinates['id'] = establishment.attributes.id;
                    establishment_coordinates['latitude'] = establishment.attributes.latitude;
                    establishment_coordinates['longitude'] = establishment.attributes.longitude;
                    establishment_coordinates['name'] = establishment.attributes.name;
                    establishment_coordinates['specials'] = establishment.attributes.specials;
                    establishment_coordinates['events'] = establishment.attributes.events;

                    return establishment_coordinates;
                });

                store.set('establishments_list_map-coordinates', geo_data);

                Nysus.listingView = new Nysus.Views.ListingView({collection: collection});
                $('#footer').fadeIn();
                Nysus.slider.slidePage(Nysus.listingView.render().$el);
            }
        });
    },

    establishment_show: function(id) {
        var establishment = new Nysus.Models.Establishment({id: id});
        establishment.fetch({
            success: function(data) {
                data.attributes.hasEvents = data.attributes['events'].length > 0

                _.each(data.attributes.events, function(event) {
                  event.event.short_start_time = formatDate(event.event.start_time);
                });

               data.attributes.hasSpecials = data.attributes['specials'].length > 0

               _.each(data.attributes.specials, function(special) {
                  special.special.short_start_time =formatDate(special.special.start_time);
               });
                console.log(data);
                Nysus.establishmentShowView = new Nysus.Views.EstablishmentShowView({model: establishment});
                Nysus.slider.slidePage(Nysus.establishmentShowView.render().$el);
            }
        })
    },

    establishments_map: function() {
        collection = new Nysus.Models.EstablishmentCollection();

        collection.fetch({
            success: function(data) {
                // Nysus.Utils.maps.storeEstablishmentsGeoData(data);

                var geo_data = _.map(data.models, function(establishment){
                    establishment_coordinates = {};
                    establishment_coordinates['id'] = establishment.attributes.id;
                    establishment_coordinates['latitude'] = establishment.attributes.latitude;
                    establishment_coordinates['longitude'] = establishment.attributes.longitude;
                    establishment_coordinates['name'] = establishment.attributes.name;
                    establishment_coordinates['specials'] = establishment.attributes.specials;
                    establishment_coordinates['events'] = establishment.attributes.events;

                    return establishment_coordinates;
                });

                store.set('establishments_list_map-coordinates', geo_data);

                Nysus.mapView = new Nysus.Views.MapView({collection: collection});
                Nysus.slider.slidePage(Nysus.mapView.render().$el);
            }
        });
    },

    login: function(){
        Nysus.loginView = new Nysus.Views.LoginView();
        Nysus.slider.slidePage(Nysus.loginView.render().$el);
    },

    account: function(){
        Nysus.accountView = new Nysus.Views.AccountView();
        Nysus.slider.slidePage(Nysus.accountView.render().$el);
    }

});