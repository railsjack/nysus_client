Nysus.Views.LoginView = Backbone.View.extend({

    tagName: 'div',

    id: 'login_view',

    events: {
        'submit #login_form': 'login',
        'submit #register_form': 'register'
    },

    initialize:function () {
        var self = this;
    },

    render:function () {
        this.$el.html(this.template());
        return this;
    },

    login: function() {
        event.preventDefault();
        var self = this;

        $.ajax({
            type: 'POST',
            url: 'http://107.170.224.217:3000/api/v1/tokens.json',
            dataType: 'json',
            data: {
                'email': this.$('input#email').val(),
                'password': this.$('input#password').val()
            },
            success: function(data) {
                self.loginSuccess(data.token)
            },
            error: function(xhr, status, error) {
                self.showError(xhr.responseJSON.message)
            }
        });
    },

    loginSuccess: function(token) {
        store.set("token", token);
        this.adjustUserMenu();

        noty({
            text: "Login Success",
            layout: 'center',
            timeout: 2000
        });


    },

    register: function() {
        event.preventDefault();
        var self = this;

        $.ajax({
            type: 'POST',
            url: 'http://107.170.224.217:3000/users.json',
            dataType: 'json',
            data: {
                'email': this.$('input#register_email').val(),
                'password': this.$('input#register_password').val()
            },
            success: function(data) {
                self.loginSuccess(data.token)
            },
            error: function(xhr, status, error) {
                self.showError(xhr.responseJSON.message)
            }
        });
    },

    registerSuccess: function(token) {
        $.ajax({
            type: 'POST',
            url: 'http://107.170.224.217:3000/api/v1/tokens.json',
            dataType: 'json',
            data: {
                'email': this.$('input#register_email').val(),
                'password': this.$('input#register_password').val()
            },
            success: function(data) {
                self.loginSuccess(data.token)
            },
            error: function(xhr, status, error) {
                self.showError(xhr.responseJSON.message)
            }
        });
    },

    showError: function(message) {
        noty({
            text: message,
            layout: 'center',
            timeout: 2000
        });
    },

    adjustUserMenu: function() {
        
    }

});
